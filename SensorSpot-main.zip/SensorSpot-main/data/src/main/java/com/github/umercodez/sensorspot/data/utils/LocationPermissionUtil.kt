package com.github.umercodez.sensorspot.data.utils

interface LocationPermissionUtil {
    fun isLocationPermissionGranted(): Boolean
}