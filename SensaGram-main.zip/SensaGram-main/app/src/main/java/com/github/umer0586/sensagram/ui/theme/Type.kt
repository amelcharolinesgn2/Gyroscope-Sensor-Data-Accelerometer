package com.github.umer0586.sensagram.ui.theme

import androidx.compose.material3.Typography

val AppTypography = Typography()
