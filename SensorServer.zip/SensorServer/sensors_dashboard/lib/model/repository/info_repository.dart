
abstract class InfoRepository {
  Future<int> getWebSocketPortNo();
}